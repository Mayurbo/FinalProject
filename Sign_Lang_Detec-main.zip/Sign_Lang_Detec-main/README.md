# Sign_Lang_Pred
## This Project is based on Detection of American Sign Language.
## The Data is prepared from the cvzone handdetector as well as from the opncv libraries. 
## The Trained Keras Model is created from the Teachable Machine Website.
## It can detect Alphabets from A-Z , numerals and also some Hand Signs.
## Libraries used are : opencv, numpy , cvzone and also Tensorflow -2.14.0  
